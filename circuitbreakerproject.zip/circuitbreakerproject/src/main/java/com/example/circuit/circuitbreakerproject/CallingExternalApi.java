package com.example.circuit.circuitbreakerproject;

import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.client.RestTemplate;

import java.net.ConnectException;

@Component
public class CallingExternalApi {

    @Autowired
    public RestTemplate restTemplate;

    private static final Logger log= LoggerFactory.getLogger(CallingExternalApi.class);
    public CallingExternalApi(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public String CallExternalApi()
    {
        ResponseEntity<String> msg = restTemplate.exchange("http://localhost:9090", HttpMethod.GET, null, String.class);
        return msg.getBody();
    }
    @ExceptionHandler({CallNotPermittedException.class})
    @ResponseStatus(value= HttpStatus.SERVICE_UNAVAILABLE)
    public void handleerrors()
    {
        log.info("Service Unavailable");
    }
    @ExceptionHandler({ConnectException.class})
    @ResponseStatus(value= HttpStatus.SERVICE_UNAVAILABLE)
    public void handleerrorsforconnect()
    {
        log.info("Service Unavailable to connect");
    }




}
