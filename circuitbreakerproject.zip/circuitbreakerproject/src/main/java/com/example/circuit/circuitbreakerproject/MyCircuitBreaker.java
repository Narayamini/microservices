package com.example.circuit.circuitbreakerproject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/")
public class MyCircuitBreaker {
    @Autowired
    private CallingExternalApi callingExternalApi;
    @GetMapping("/circuitbreaker")
    public String circuitmethod()
    {
        return callingExternalApi.CallExternalApi();
    }

}
