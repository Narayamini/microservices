package com.example.circuit.circuitbreakerproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CircuitbreakerprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
