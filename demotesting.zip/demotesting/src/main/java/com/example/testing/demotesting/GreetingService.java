package com.example.testing.demotesting;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import jakarta.websocket.server.PathParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.Scanner;
import java.util.concurrent.TimeoutException;

@RestController

public class GreetingService {
    private static String QUEUE = "MyFirstQueue";

    @GetMapping("/")
    public String hello()
    {
        return "Welcome to my world";
    }
    @GetMapping("/greeting{name}")
    public String helloint(@PathVariable(value="name") String candidateName)
    {
        try {
            return sendRabbitMQMessage(candidateName);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (TimeoutException e) {
            throw new RuntimeException(e);
        }
        //return "Message Not Delivered";
    }
    public String sendRabbitMQMessage(String personName) throws IOException, TimeoutException
    {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        try (
                Connection connection = factory.newConnection();
                Channel channel = connection.createChannel()) {
            channel.queueDeclare(QUEUE, false, false, false, null);


                channel.basicPublish("", QUEUE, null, personName.getBytes());



        }
        return "Message Sent";
    }

}
