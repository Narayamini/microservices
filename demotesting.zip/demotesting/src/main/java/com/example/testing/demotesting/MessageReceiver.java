package com.example.testing.demotesting;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.concurrent.TimeoutException;

public class MessageReceiver {
    private static String QUEUE = "MyFirstQueue";
    private static final Logger log= LoggerFactory.getLogger(MessageReceiver.class);


    public String receiveMessage() {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");

        Connection connection = null;
        try {
            connection = factory.newConnection();
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (TimeoutException e) {
            throw new RuntimeException(e);
        }
        Channel channel = null;
        try {
            channel = connection.createChannel();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            channel.queueDeclare(QUEUE, false, false, false, null);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
//            Scanner input=new Scanner(System.in);
//            String message;
        //do {
       // log.info("waiting for messges");
        System.out.println("Waiting for messages");
        DeliverCallback deliverCallback = (consumerTag, delivery) -> {
            String message = new String(delivery.getBody(), StandardCharsets.UTF_8);
            System.out.println("Received '" + message + "'");
        };
        try {
            channel.basicConsume(QUEUE, true, deliverCallback, consumerTag -> {
            });
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return "MessageReceived";
    }

//                message = input.nextLine();
//                channel.basicPublish("", QUEUE, null, message.getBytes());
//            }
//            while(!message.equalsIgnoreCase("Quit"));


}
