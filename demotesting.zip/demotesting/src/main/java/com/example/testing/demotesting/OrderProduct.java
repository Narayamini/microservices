package com.example.testing.demotesting;

import jakarta.persistence.*;

import java.util.List;

@Entity
public class OrderProduct {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Long IdNo;
    private String totalPrice,created,status,shipmentAddress,shipmentDate;

    public Long getIdNo() {
        return IdNo;
    }

    public void setIdNo(Long idNo) {
        IdNo = idNo;
    }

    public List<Customer> getCustomer() {
        return customer;
    }

    public void setCustomer(List<Customer> customer) {
        this.customer = customer;
    }

    @ManyToMany
    private List<Customer> customer;
//    public Long getId() {
//        return IdNo;
//    }

    public OrderProduct(Long IdNo, String totalPrice, String created, String status, String shipmentAddress, String shipmentDate) {
        this.IdNo = IdNo;
        this.totalPrice = totalPrice;
        this.created = created;
        this.status = status;
        this.shipmentAddress = shipmentAddress;
        this.shipmentDate = shipmentDate;
    }

    public void setId(Long IdNo) {
        this.IdNo = IdNo;
    }

    public String getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(String totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getShipmentAddress() {
        return shipmentAddress;
    }

    public void setShipmentAddress(String shipmentAddress) {
        this.shipmentAddress = shipmentAddress;
    }

    public String getShipmentDate() {
        return shipmentDate;
    }

    public void setShipmentDate(String shipmentDate) {
        this.shipmentDate = shipmentDate;
    }
}
