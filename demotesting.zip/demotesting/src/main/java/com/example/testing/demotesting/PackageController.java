package com.example.testing.demotesting;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class PackageController {
    @Autowired
    private PackageRepository packageRepository;

    @GetMapping("/order")
    public List<OrderProduct> listOrderDetails()
    {
        return packageRepository.findAll();

    }
//    @PutMapping("/order")
//    public
}

