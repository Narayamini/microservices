package com.example.testing.demotesting;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.*;
@RestController
public class StudentServiceController {
    private static Map<String, List<Student>> schoolDb=new HashMap<String, List<Student>>();

    static{schoolDb=new HashMap<String, List<Student>>();
        List<Student> lst = new ArrayList<Student>();
        Student std=new Student(1L,"name","phone","city");
        lst.add(std);
        schoolDb.put("njhs",lst);

    }
    @RequestMapping(value="/getStudentDetailsForSchool/{schoolname}",method= RequestMethod.GET)
    public List<Student> getStudents(@PathVariable String schoolname)
    {
        System.out.println("Getting student details for "+ schoolname);
        List<Student> studentList=schoolDb.get(schoolname);
        if(studentList == null)
        {
            studentList=new ArrayList<Student>();
            Student std=new Student(1L,"Not found","not found","na");
            studentList.add(std);
        }
        return studentList;
    }
















}
