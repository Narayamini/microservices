package com.example.testing.demotesting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemotestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
