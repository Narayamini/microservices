package com.example.testing.demotestinggradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemotestinggradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
