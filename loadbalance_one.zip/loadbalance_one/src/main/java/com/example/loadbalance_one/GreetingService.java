package com.example.loadbalance_one;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


    @RestController
    public class GreetingService {

        @GetMapping("/")
        public String hello()
        {
            return "Hello";
        }
}
