package com.example.loadbalance_two;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
public class GreetingService {

    @GetMapping("/")
    public String hello()
    {
        return "Hello";
    }

//    @GetMapping("/all_password_encoder")
//    public String allPasswordEncoder()
//    {
//        String idForEncode = "aaa@123";
//        Map encoders =  new HashMap<>();
//        encoders.put(idForEncode, new BCryptPasswordEncoder();
//        encoders.put(pdkdf2, new BCryptPasswordEncoder();
//
//    }
}
