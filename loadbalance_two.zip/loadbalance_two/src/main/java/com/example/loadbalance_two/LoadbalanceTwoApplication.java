package com.example.loadbalance_two;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class LoadbalanceTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoadbalanceTwoApplication.class, args);
	}

}
