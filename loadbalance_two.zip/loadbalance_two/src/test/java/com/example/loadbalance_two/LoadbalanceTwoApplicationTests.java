package com.example.loadbalance_two;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoadbalanceTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
