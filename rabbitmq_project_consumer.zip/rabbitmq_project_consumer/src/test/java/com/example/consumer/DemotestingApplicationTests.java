package com.example.consumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemotestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
