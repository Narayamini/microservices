package com.example.testing.demotesting;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.*;

@RestController
public class StudentController {
    @Autowired
    private StudentRepository studentRepository;
    @GetMapping("/student")
    public List<Student> listAllStudents()
    {
        return studentRepository.findAll();
    }
    @PostMapping("/addstudent")
    public Student studentdata(Student student)

    {
        return studentRepository.save(student);
    }
    @PutMapping ("/student")
    public Student updatedata(Student student)

    {
        return studentRepository.save(student);
    }
    @DeleteMapping("/student")
    public String deletedata(Student student)

    {
        studentRepository.delete(student);
        return "Deleted";

    }

    @PutMapping("/student/{rollno}")
    public Student updateDataofStudent(@PathVariable("rollno") Long rollno,Student student)

    {
        Optional<Student> studenttobeupdated = studentRepository.findById(rollno);
        Student std=studenttobeupdated.get();
        if(student.getCity()!=null)
        {
            std.setCity(student.getCity());
        }
        std.setCity(student.getCity());
        std.setName(student.getName());
        std.setPhone(student.getPhone());


        return studentRepository.save(std);
    }
        @DeleteMapping("student/{rollno}")

        public String deletedataof(@PathVariable("rollno") Long rollno)

        {Student studenttobedeleted= studentRepository.findById(rollno).get();


            studentRepository.delete(studenttobedeleted);
            return "Studentdeleted";
        }
    }

