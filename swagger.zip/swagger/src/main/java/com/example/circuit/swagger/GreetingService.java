package com.example.circuit.swagger;

import jakarta.websocket.server.PathParam;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class GreetingService {
    @Value("${author:No author}")
    private static String author;
    @GetMapping("/")
    public String hello()
    {
        return "Welcome to my world" + author;
    }
    @GetMapping("/greeting{name}")
    public String helloint(@PathVariable(value="name") String candidateName)
    {
        return "Welcome to my world "+candidateName;
    }

}
