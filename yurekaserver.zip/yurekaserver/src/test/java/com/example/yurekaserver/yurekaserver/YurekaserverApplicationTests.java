package com.example.yurekaserver.yurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YurekaserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
